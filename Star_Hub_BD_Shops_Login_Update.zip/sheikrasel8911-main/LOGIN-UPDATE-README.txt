Star Hub BD Shops - Customer Login Update

Added:
- /login page with Login and Registration tabs
- Bangladesh mobile number + password authentication (no OTP)
- Passwords stored as scrypt hashes (not plaintext)
- User records stored in DATA_DIR/users.json
- Customer API: POST /api/user/register, POST /api/user/login, GET /api/user/me, POST /api/user/logout
- Existing Admin Panel routes and credentials are unchanged.

Deployment:
1. Replace the existing repository files with the contents of this ZIP (keep the same project root).
2. Commit and push to the same GitHub branch connected to Render.
3. Wait for Render deployment to finish.
4. Open https://YOUR-SITE/login or tap the profile icon on the home page.
5. Register using a Bangladesh mobile number and a password of at least 6 characters.

Important:
- Set DATA_DIR to a persistent disk path on Render if you want user accounts to survive deploys/restarts. Without persistent storage, users.json may be lost when the instance filesystem is replaced.
- This update adds customer account registration/login only. It does not implement payments, wallet deposits, order placement, or automatic top-up delivery.
